-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generato il: Feb 24, 2014 alle 02:16
-- Versione del server: 5.5.27
-- Versione PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agenda`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `appuntamenti_giuseppe65`
--

DROP TABLE IF EXISTS `appuntamenti_giuseppe65`;
CREATE TABLE IF NOT EXISTS `appuntamenti_giuseppe65` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(20) DEFAULT NULL,
  `gsett_inizio` varchar(9) DEFAULT NULL,
  `data_inizio` date DEFAULT NULL,
  `ora_inizio` time DEFAULT NULL,
  `gsett_fine` varchar(9) DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `ora_fine` time DEFAULT NULL,
  `descrizione` varchar(50) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `appuntamenti_pietro76`
--

DROP TABLE IF EXISTS `appuntamenti_pietro76`;
CREATE TABLE IF NOT EXISTS `appuntamenti_pietro76` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(20) DEFAULT NULL,
  `gsett_inizio` varchar(9) DEFAULT NULL,
  `data_inizio` date DEFAULT NULL,
  `ora_inizio` time DEFAULT NULL,
  `gsett_fine` varchar(9) DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `ora_fine` time DEFAULT NULL,
  `descrizione` varchar(50) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struttura della tabella `appuntamenti_stefano83`
--

DROP TABLE IF EXISTS `appuntamenti_stefano83`;
CREATE TABLE IF NOT EXISTS `appuntamenti_stefano83` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(20) DEFAULT NULL,
  `gsett_inizio` varchar(9) DEFAULT NULL,
  `data_inizio` date DEFAULT NULL,
  `ora_inizio` time DEFAULT NULL,
  `gsett_fine` varchar(9) DEFAULT NULL,
  `data_fine` date DEFAULT NULL,
  `ora_fine` time DEFAULT NULL,
  `descrizione` varchar(50) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dump dei dati per la tabella `appuntamenti_stefano83`
--

INSERT INTO `appuntamenti_stefano83` (`id`, `categoria`, `gsett_inizio`, `data_inizio`, `ora_inizio`, `gsett_fine`, `data_fine`, `ora_fine`, `descrizione`, `note`) VALUES
(2, 'Lavoro', 'lunedì', '2014-02-24', '09:00:00', 'lunedì', '2014-02-24', '18:00:00', 'Inizio stage corso IFTS', 'Progetto Realtà Aumentata'),
(3, 'Tempo libero', 'sabato', '2014-02-25', '20:30:00', 'mercoledì', '2014-02-26', '22:30:00', 'Cena con amici', 'Ristorante La Pergola'),
(6, 'Visite sanitarie', 'martedì', '2014-02-25', '06:30:00', 'martedì', '2014-02-25', '07:00:00', 'Visita cardiologica', 'Portare documentazione degli ultimi 5 anni');

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `Descrizione` varchar(50) NOT NULL,
  PRIMARY KEY (`Descrizione`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `categorie`
--

INSERT INTO `categorie` (`Descrizione`) VALUES
('Anniversari'),
('Eventi'),
('Lavoro'),
('Riunioni'),
('Tempo libero'),
('Visite sanitarie');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

DROP TABLE IF EXISTS `utenti`;
CREATE TABLE IF NOT EXISTS `utenti` (
  `Nome` varchar(50) NOT NULL,
  `Cognome` varchar(50) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Immagine` varchar(7) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`Nome`, `Cognome`, `Username`, `Password`, `Immagine`) VALUES
('Giuseppe', 'Verdi', 'giuseppe65', 'musica', 'pera'),
('Pietro', 'Santoro', 'pietro76', 'meucci', 'uva'),
('Stefano', 'Salamanna', 'stefano83', 'corso', 'arancia');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
